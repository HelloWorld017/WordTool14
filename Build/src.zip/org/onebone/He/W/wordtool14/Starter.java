package org.onebone.He.W.wordtool14;

public class Starter {
	public static void main(String[] args){
		new MainActivity();
	}
}
